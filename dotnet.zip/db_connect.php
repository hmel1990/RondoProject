<?php 
        define('HOST', 'fdb1030.awardspace.net');
        define('USER', '4621564_db');
        define('PASS', 'pe4en6ka');
        define('DB',   '4621564_db');
 
        $con = mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect to db');
 ?>